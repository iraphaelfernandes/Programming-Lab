#include <stdio.h>

int main(void)
{
  printf("EOF: %d", EOF);
  return 0;
}


// NOTE: The value of the EOF character is -1, which is an integer.
