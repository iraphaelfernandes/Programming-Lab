#include <stdio.h>

int main(void)
{
  printf("hello: \n");
  return 0;
}


// NOTE: The compiler doesn't recognize the '\c' as an escape sequence and throws
// a warning to let us know that.
